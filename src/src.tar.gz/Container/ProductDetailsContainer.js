import React, {Component} from 'react'
import ProductDetailsComponent from '../Component/ProductDetailsComponent'
import '../../node_modules/bootstrap/dist/css/bootstrap.min.css';

class ProductDetailsContainer extends Component{
    constructor() {
        this.handleAddToCart = this.handleAddRoCart.bind(this);
        this.handleBack = this.handleBack.bind(this);

        return {
          product: {
            image: '',
            title: '',
            description: '',
            price: 0,
            quantity: 0,
          }
        };
      }
    
      handleAddToCart() {
        var body = {
          id: this.state.product.id,
          image: this.state.product.image,
          title: this.state.product.title
        };
        // axios.post('/api/users/' + UserService.getUsername() + '/cart-products', body).then(function() {
        //   EventEmitter.publish({ eventType: 'AddToCart' });
        // });
      }
    
      handleBack() {
        this.context.router.push('/products');
      }
    
      render() {
          var props = {product: this.state.product, onAddToCart: this.handelAddToCart, onBack: this.handleBack}
        return (
            <ProductDetailsComponent {...props} />
        );
      }
    };
    
    ProductDetailsContainer.contextTypes = {
      router: React.PropTypes.object.isRequired,
    };
    

export default ProductDetailsContainer;